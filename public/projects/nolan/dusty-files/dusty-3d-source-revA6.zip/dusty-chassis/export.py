import os, sys, json, math, pickle, zipfile
import numpy as np, trimesh
from build import *
from rev import REV
OUT = sys.argv[1]; os.makedirs(OUT, exist_ok=True)

def tm(s):
    mm = s.to_mesh(); return trimesh.Trimesh(np.array(mm.vert_properties)[:, :3], np.array(mm.tri_verts), process=False)

def on_bed(t):
    t = t.copy(); b = t.bounds
    t.apply_translation([-(b[0][0] + b[1][0])/2, -(b[0][1] + b[1][1])/2, -b[0][2]]); return t

ax_s, AXL = axle()
flip = lambda s: s.rotate([180, 0, 0])
parts = {  # name: (manifold in print orientation, qty, note)
 'base':        (base(print_fin=True).rotate([0, 180, 0]), 1, 'top face down, lift off the support block under the gear peg'),
 'deck':        (deck(), 1, ''),
 'post':        (flip(post()), 2, 'peg up'),
 'sleeve':      (sleeve().rotate([0, 90, 0]), 1, 'standing on its closed end'),
 'keeper':      (keeper(), 1, 'head down flat'),
 'cradle':      (cradle(), 1, ''),
 'tray':        (tray().rotate([tray_print_tilt(), 0, 0]), 1, 'sloped underside flat on the bed'),
 'roller':      (roller(), 1, 'standing'),
 'axle':        (ax_s.rotate([0, 90, 0]).rotate([90, 0, 0]).rotate([180, 0, 0]), 1, 'flat side down'),
 'collar':      (collar(), 1, ''),
 'pinion':      (pinion(), 1, ''),
 'compound_gear': (compound(), 1, 'big gear down'),
 'roller_gear': (roller_gear(), 1, ''),
 'washer':      (washer(), 1, ''),
 'sensor_carrier_R': (carrier(1), 1, ''),
 'sensor_carrier_L': (carrier(-1, whisker=True), 1, 'has whisker-switch pad'),
 'dowel':       (dowel(), 2, ''),
 'deck_coupon': (deck_coupon(), 1, 'hole test: deck corner'),
 'base_coupon': (base_coupon().rotate([0, 180, 0]), 1, 'hole test: base patch, top face down'),
}
meshes = {}
for k, (s, q, note) in parts.items():
    t = on_bed(tm(s))
    meshes[k] = t
    t.export(os.path.join(OUT, f'dusty-{k}-{REV}.stl'))
    b = t.bounds; print(f'{k:18s} x{q}  {np.round(b[1]-b[0],1)}  {round(t.volume/1000*1.24,1)} g solid  {note}')

az = meshes['axle'].vertices[:, 2]; print('axle bed contact verts', int((az < 0.01).sum()))

# plate layout on 220 x 220 (Adventurer 5M)
place = [  # (name, x, y, rotz)
 ('base', -62, 0, 0),
 ('deck', 51, 69, 0),
 ('tray', 30, -8, 90),
 ('roller', -4.75, 55, 0),
 ('roller_gear', -4.75, 82, 0),
 ('axle', 30, -48, 0),
 ('compound_gear', 80, 10, 0),
 ('pinion', 102, 36, 0),
 ('collar', 104, 18, 0),
 ('washer', 104, 4, 0),
 ('sensor_carrier_R', 75, -40, 90),
 ('sensor_carrier_L', 98, -40, 90),
 ('cradle', 42, -80, 0),
 ('post', 80, -72, 0), ('post', 88, -72, 0),
 ('sleeve', -62, 88, 90), ('keeper', -62, -72, 90),
 ('dowel', 80, -84, 0), ('dowel', 86, -84, 0),
]
plate = []
boxes = []
for name, x, y, rz in place:
    t = meshes[name].copy()
    t.apply_transform(trimesh.transformations.rotation_matrix(math.radians(rz), [0, 0, 1]))
    b = t.bounds; t.apply_translation([x - (b[0][0]+b[1][0])/2, y - (b[0][1]+b[1][1])/2, -b[0][2]])
    plate.append(t); boxes.append((name, t.bounds[0][:2], t.bounds[1][:2]))
pl = trimesh.util.concatenate(plate)
pb = pl.bounds; print('plate bounds', np.round(pb, 1), 'size', np.round(pb[1]-pb[0], 1))
bad = []
for i in range(len(boxes)):
    for j in range(i+1, len(boxes)):
        (n1, a0, a1), (n2, b0, b1) = boxes[i], boxes[j]
        if (a0[0] < b1[0]+2 and b0[0] < a1[0]+2 and a0[1] < b1[1]+2 and b0[1] < a1[1]+2):
            bad.append((n1, n2))
print('overlaps', bad)
pl.export(os.path.join(OUT, f'dusty-chassis-all-parts-plate-{REV}.stl'))
with zipfile.ZipFile(os.path.join(OUT, f'dusty-chassis-{REV}-stl.zip'), 'w', zipfile.ZIP_DEFLATED) as z:
    for k in parts:
        z.write(os.path.join(OUT, f'dusty-{k}-{REV}.stl'), f'dusty-{k}-{REV}.stl')
    z.write(os.path.join(OUT, f'dusty-chassis-all-parts-plate-{REV}.stl'), f'dusty-chassis-all-parts-plate-{REV}.stl')
pickle.dump((np.asarray(pl.vertices), np.asarray(pl.faces)), open(os.path.join(OUT, 'plate.pkl'), 'wb'))
