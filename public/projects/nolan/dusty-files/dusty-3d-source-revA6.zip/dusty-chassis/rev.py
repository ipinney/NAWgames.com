# Design revision tag. A download carries the revision in which that file last changed (publish.py keeps
# download can't be mistaken for the current one. Bump it with each MOC that changes a part.
REV = 'revA6'   # MOC-006 (Sep 27 2026)
